screen-share
------------
gotty with tor


- HOW TO USE 
```sh
git clone https://github.com/2i08ueivktd0/GOTTYTOR.git
cd GOTTYTOR
chmod +x *
./GottyTOR.sh
```
